/**
 * 
 */
package ast;

/**
 * @author md
 *
 */
public enum PrimitiveType {
	BOOL, INT, CHAR, STR, FLOAT, LIST, TUPLE
}
