package ast.statements;

import ast.Node;

public abstract class StmtNode extends Node {
	
} 
