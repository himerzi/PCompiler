package ast.sequences;

import ast.expressions.ExprNode;

public abstract class SequenceNode extends ExprNode {


}
