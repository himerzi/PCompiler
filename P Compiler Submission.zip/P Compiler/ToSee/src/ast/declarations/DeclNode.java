package ast.declarations;

import ast.Node;

public abstract class DeclNode extends Node {

}
